/* E2E 第二轮：本轮 5 项改动验证
   A. 公告弹窗倒计时 1 秒 + 引导弹窗精简（仅称呼）
   B. 自带供应商仅 SiliconFlow + 零 CDN 请求
   C. 小说生成页多 Key 打通（同步 /  chips / 切换 / 并发拉取）
*/
const { chromium } = require('playwright');

const BASE = 'http://localhost:8899/index.html';
const FAKE_MODELS = {
    object: 'list',
    data: [
        { id: 'e2e-model-alpha', object: 'model', owned_by: 'e2e' },
        { id: 'e2e-model-beta', object: 'model', owned_by: 'e2e' }
    ]
};

(async () => {
    const browser = await chromium.launch();
    const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
    const errors = [];
    page.on('pageerror', e => errors.push('[pageerror] ' + e.message));
    page.on('console', m => { if (m.type() === 'error') errors.push('[console] ' + m.text()); });

    // 收集所有非本地请求（含 iframe 内）
    const externalRequests = [];
    page.on('request', req => {
        const url = req.url();
        if (!/^https?:\/\/(localhost|127\.0\.0\.1)(:|\/|$)/.test(url)) externalRequests.push(url);
    });

    // 拦截 /v1/models
    let modelsRequestCount = 0;
    const modelsAuthKeys = [];
    await page.route('**/v1/models*', route => {
        modelsRequestCount++;
        try {
            modelsAuthKeys.push((route.request().headers()['authorization'] || '').replace(/^Bearer\s+/i, ''));
        } catch (e) { modelsAuthKeys.push(''); }
        route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(FAKE_MODELS) });
    });

    const results = [];
    const check = (name, ok, detail) => {
        results.push({ name, ok, detail: detail || '' });
        console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail ? ' | ' + detail : ''}`);
    };

    const getState = () => page.evaluate(() => {
        const proxy = document.querySelector('#app')._vnode.component.proxy;
        return {
            apiProviderId: proxy.settings.apiProviderId,
            apiKey: proxy.settings.apiKey,
            savedApiKeys: [...(proxy.savedApiKeys || [])],
            customApiProviders: (proxy.settings.customApiProviders || []).map(p => p.id),
            builtinProviderCount: (proxy.apiProviderOptions || []).length
        };
    });

    // ================= 阶段 A：新用户公告 + 引导 =================
    await page.addInitScript(() => {
        try { localStorage.clear(); } catch (e) {}
    });
    await page.goto(BASE, { waitUntil: 'domcontentloaded' });

    const ackBtn = page.locator('.app-modal-overlay button:has-text("知道了")').first();
    await ackBtn.waitFor({ state: 'attached', timeout: 10000 });
    await page.waitForTimeout(250);
    const initialText = ((await ackBtn.textContent().catch(() => '')) || '').trim();
    const initialDisabled = await ackBtn.isDisabled().catch(() => null);
    check('A1 公告弹窗出现，按钮初始禁用（倒计时未结束）',
        initialDisabled === true && /\(\d+s\)/.test(initialText),
        `text="${initialText}" disabled=${initialDisabled}`);

    let waitMs = 0;
    let enabled = false;
    for (let i = 0; i < 40; i++) {
        if (await ackBtn.isEnabled().catch(() => false)) { enabled = true; break; }
        await page.waitForTimeout(100);
        waitMs += 100;
    }
    check('A2 公告按钮约 1 秒后即可点击', enabled && waitMs <= 1800,
        `enabled=${enabled} 等待 ${waitMs}ms`);

    await ackBtn.click();
    await page.waitForTimeout(500);
    const ackVisible = await ackBtn.isVisible().catch(() => false);
    const updateId = await page.evaluate(() => localStorage.getItem('roleplay_hub_update_id'));
    check('A3 点击后公告关闭并写入 roleplay_hub_update_id',
        !ackVisible && updateId === '10222', `update_id=${updateId}`);

    // 引导弹窗
    const setupSave = page.locator('.app-modal-overlay button:has-text("保存并开始")').first();
    await setupSave.waitFor({ state: 'visible', timeout: 5000 });
    const setupOverlayText = await page.locator('.app-modal-overlay:visible').first().innerText();
    check('A4 引导弹窗仅含称呼字段（无视角 / 详细设定 / 叙事）',
        !/视角|详细设定|叙事/.test(setupOverlayText) && setupOverlayText.includes('角色对您的称呼'),
        setupOverlayText.replace(/\s+/g, ' ').slice(0, 90));
    const setupDisabled = await setupSave.isDisabled();
    await page.locator('.app-modal-overlay:visible input[placeholder="角色对您的称呼"]').fill('测试用户');
    await page.waitForTimeout(200);
    const setupEnabledAfter = await setupSave.isEnabled();
    check('A5 引导弹窗称呼为空时禁用，填写后可保存',
        setupDisabled === true && setupEnabledAfter === true, `empty=${setupDisabled} filled=${setupEnabledAfter}`);
    await setupSave.click();
    await page.waitForTimeout(600);
    const setupGone = await page.locator('.app-modal-overlay:visible').count();
    check('A6 保存后引导弹窗关闭进入主界面', setupGone === 0, `visible overlays=${setupGone}`);

    // ================= 阶段 B：供应商仅 SiliconFlow + 零 CDN =================
    const cdnHits = externalRequests.filter(u =>
        /cdn\.tailwindcss\.com|unpkg\.com|cdn\.jsdelivr\.net|cdn\.sta1n\.cn/.test(u));
    check('B1 页面加载无 Tailwind / unpkg / jsdelivr / sta1n CDN 请求',
        cdnHits.length === 0,
        cdnHits.length ? cdnHits.slice(0, 3).join(' , ') : `外部请求 ${externalRequests.length} 个均为 Google Fonts/其他`);
    const vendorOk = await page.evaluate(async () => {
        const paths = ['assets/vendor/tailwind.js', 'assets/vendor/vue.global.prod.js',
            'assets/vendor/marked.min.js', 'assets/vendor/purify.min.js', 'assets/vendor/Sortable.min.js'];
        const out = {};
        for (const p of paths) {
            try { out[p] = (await fetch(p)).status; } catch (e) { out[p] = 'ERR'; }
        }
        return out;
    });
    check('B2 五个本地 vendor 文件均可访问',
        Object.values(vendorOk).every(s => s === 200), JSON.stringify(vendorOk));

    // 打开设置
    await page.locator('.app-nav-trigger:visible').first().click();
    await page.waitForSelector('#app-navigation-panel', { state: 'visible', timeout: 3000 });
    await page.locator('#app-navigation-panel button:has-text("设置")').first().click();
    await page.waitForTimeout(800);

    const trigger = page.locator('.api-provider-selector-container > button.settings-control').first();
    await trigger.click();
    await page.waitForTimeout(300);
    const dropdown = page.locator('.api-provider-selector-container div.absolute').first();
    const optionTexts = await dropdown.locator('button').allInnerTexts();
    const optionNames = optionTexts.map(t => t.replace(/\s+/g, ' ').trim());
    check('B3 供应商下拉仅 SiliconFlow + 添加供应商',
        optionNames.length === 2
        && optionNames.some(t => t.includes('SiliconFlow'))
        && optionNames.some(t => t.includes('添加供应商')),
        JSON.stringify(optionNames));
    await page.keyboard.press('Escape').catch(() => {});
    await page.locator('body').click({ position: { x: 5, y: 5 } }).catch(() => {});
    await page.waitForTimeout(200);

    // 配置两个 Key
    const keyInput = page.locator('input[placeholder="sk-..."]').first();
    await keyInput.fill('sk-e2e-key-alpha');
    await page.locator('button:has-text("保存当前密钥")').first().click();
    await page.waitForTimeout(300);
    await keyInput.fill('sk-e2e-key-beta');
    await page.locator('button:has-text("保存当前密钥")').first().click();
    await page.waitForTimeout(300);
    const stateB = await getState();
    check('B4 SiliconFlow 已保存 2 个 Key',
        stateB.apiProviderId === 'siliconflow'
        && (stateB.savedApiKeys || []).length === 2,
        `provider=${stateB.apiProviderId} keys=${JSON.stringify(stateB.savedApiKeys)} builtin=${stateB.builtinProviderCount}`);

    // ================= 阶段 C：小说生成页多 Key =================
    await page.locator('.app-nav-trigger:visible').first().click();
    await page.waitForSelector('#app-navigation-panel', { state: 'visible', timeout: 3000 });
    await page.locator('#app-navigation-panel button:has-text("小说生成")').first().click();
    await page.waitForTimeout(2500);

    const novelFrame = page.frames().find(f => f.url().includes('/novel/index.html'));
    check('C0 小说生成页 iframe 已加载', !!novelFrame, novelFrame ? novelFrame.url() : 'frame not found');

    if (novelFrame) {
        // 先打开设置面板（供应商信息在设置弹窗内，隐藏时 innerText 不可见）
        await novelFrame.locator('button[title="设置"]').first().click();
        await novelFrame.waitForTimeout(500);
        // 等同步完成：供应商触发器显示「已配置 2 个 Key」
        let keyCountText = '';
        for (let i = 0; i < 40; i++) {
            const bodyText = await novelFrame.locator('body').innerText().catch(() => '');
            if (bodyText.includes('已配置 2 个 Key')) { keyCountText = '已配置 2 个 Key'; break; }
            await novelFrame.evaluate(() => new Promise(r => setTimeout(r, 200)));
        }
        check('C1 小说页自动同步后显示「已配置 2 个 Key」',
            keyCountText.includes('已配置 2 个 Key'), keyCountText || '未出现');

        // Key chips
        const chips = novelFrame.locator('button:has-text("使用中"), .mt-2.flex.flex-wrap button');
        const chipCount = await chips.count().catch(() => 0);
        const usingCount = await novelFrame.locator('button:has-text("使用中")').count().catch(() => 0);
        check('C2 Key chips 渲染（2 个 Key，1 个「使用中」）',
            chipCount >= 2 && usingCount === 1, `chips=${chipCount} 使用中=${usingCount}`);

        const novelStateBefore = await novelFrame.evaluate(() => {
            const proxy = document.querySelector('#app')._vnode.component.proxy;
            return {
                providerId: proxy.settings.providerId,
                apiKey: proxy.settings.apiKey,
                apiKeys: [...(proxy.currentProviderKeys || [])],
                modelCount: (proxy.availableModels || []).length
            };
        });
        const readStoredSelections = () => novelFrame.evaluate(() => new Promise((resolve) => {
            // novel 页库存放在 IndexedDB(RPHubDB/store)，键 rp_hub_novel_library
            let request;
            try { request = indexedDB.open('RPHubDB'); } catch (e) { resolve(null); return; }
            request.onerror = () => resolve(null);
            request.onsuccess = () => {
                const db = request.result;
                if (!db.objectStoreNames.contains('store')) { db.close(); resolve(null); return; }
                const tx = db.transaction('store', 'readonly').objectStore('store').get('rp_hub_novel_library');
                tx.onsuccess = () => resolve(tx.result?.globalSettings?.providerKeySelections || null);
                tx.onerror = () => resolve(null);
            };
        }));
        const countBefore = modelsRequestCount;
        const authBefore = [...modelsAuthKeys];

        // 切换到第二个 Key
        const otherKey = novelStateBefore.apiKeys.find(k => k !== novelStateBefore.apiKey);
        if (otherKey) {
            const chipBtn = novelFrame.locator(`button[title="${otherKey}"]`).first();
            await chipBtn.click();
            // 等待模型列表重新填充（selectProviderKey 会先清空再拉取）
            let waited = 0;
            let modelsReady = false;
            while (waited < 10000) {
                const cnt = await novelFrame.evaluate(() =>
                    (document.querySelector('#app')._vnode.component.proxy.availableModels || []).length).catch(() => 0);
                if (cnt > 0) { modelsReady = true; break; }
                await novelFrame.evaluate(() => new Promise(r => setTimeout(r, 150)));
                waited += 150;
            }
            check('C3a 切换 Key 后模型列表重新填充', modelsReady, `等待 ${waited}ms`);
            const novelStateAfter = await novelFrame.evaluate(() => {
                const proxy = document.querySelector('#app')._vnode.component.proxy;
                return {
                    apiKey: proxy.settings.apiKey,
                    modelCount: (proxy.availableModels || []).length
                };
            });
            const storedSelections = await readStoredSelections();
            check('C3b 切换 Key 后：apiKey 更新、偏好持久化（IndexedDB）',
                novelStateAfter.apiKey === otherKey
                && storedSelections?.siliconflow === otherKey
                && novelStateAfter.modelCount === FAKE_MODELS.data.length,
                `apiKey=${novelStateAfter.apiKey} stored=${JSON.stringify(storedSelections)} models=${novelStateAfter.modelCount}`);
            await novelFrame.evaluate(() => new Promise(r => setTimeout(r, 600)));
            const settledAuth = modelsAuthKeys.slice(authBefore.length);
            const uniqueAuth = [...new Set(settledAuth)];
            check('C4 多 Key 并发拉取（一次 fetchModels 用完全部 Key）',
                settledAuth.length >= 2 && uniqueAuth.length === 2,
                `本次请求 ${settledAuth.length} 次，Key=[${uniqueAuth.join(', ')}]`);
        } else {
            check('C3 切换 Key', false, '找不到第二个 Key');
            check('C4 多 Key 并发拉取', false, '前置失败');
        }

        // iframe 内 Vue 运行时错误
        const novelErrors = await novelFrame.evaluate(() => window.__novelErrors || []);
        check('C5 小说页无 Vue 运行时错误', (novelErrors || []).length === 0,
            (novelErrors || []).slice(0, 2).join(' ; '));
    }

    // 汇总
    console.log('\n================ 汇总 ================');
    const pass = results.filter(r => r.ok).length;
    const fail = results.filter(r => !r.ok).length;
    results.forEach(r => console.log(`${r.ok ? 'PASS' : 'FAIL'} | ${r.name}${r.detail ? ' | ' + r.detail : ''}`));
    console.log(`\n总计 ${results.length} 项：通过 ${pass}，失败 ${fail}`);
    if (errors.length) {
        console.log('\n---- 页面错误 ----');
        errors.slice(0, 10).forEach(e => console.log(e));
    }
    await browser.close();
    process.exit(fail > 0 ? 1 : 0);
})().catch(e => { console.error('E2E 脚本异常:', e); process.exit(2); });
