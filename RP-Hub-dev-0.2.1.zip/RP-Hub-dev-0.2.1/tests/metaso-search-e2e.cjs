/* E2E：秘塔联网搜索工具（默认出现 / 启用 / Key 持久化 / 调用链路 / UI 展示） */
const { chromium } = require('playwright');

const BASE = 'http://localhost:8899/index.html';
const FAKE_MODELS = { object: 'list', data: [
    { id: 'e2e-model-alpha', object: 'model', owned_by: 'e2e' },
    { id: 'e2e-model-beta', object: 'model', owned_by: 'e2e' }
]};
const FAKE_METASO = {
    errCode: 0,
    errMsg: 'success',
    data: {
        text: '李白是唐代著名诗人，代表作有《静夜思》《将进酒》等[1]。',
        sessionId: 'sess_e2e_001',
        sources: [
            { title: '李白_百度百科', link: 'https://baike.baidu.com/item/libai', content: '李白（701－762），字太白，号青莲居士。' },
            { title: '李白诗集', link: 'https://example.com/libai-poems', content: '收录李白主要诗作。' }
        ]
    }
};

(async () => {
    const browser = await chromium.launch();
    const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
    const errors = [];
    page.on('pageerror', e => errors.push('[pageerror] ' + e.message));
    page.on('console', m => { if (m.type() === 'error') errors.push('[console] ' + m.text()); });

    await page.addInitScript(() => {
        try { localStorage.clear(); } catch (e) {}
        try { localStorage.setItem('roleplay_hub_update_id', '99999'); } catch (e) {}
    });

    // 模型列表拦截
    await page.route('**/v1/models*', route => route.fulfill({
        status: 200, contentType: 'application/json', body: JSON.stringify(FAKE_MODELS)
    }));

    // 秘塔 API 拦截
    const metasoRequests = [];
    await page.route('**/api/open/search/**', route => {
        metasoRequests.push({
            url: route.request().url(),
            auth: route.request().headers()['authorization'] || '',
            body: route.request().postDataJSON() || {}
        });
        route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(FAKE_METASO) });
    });

    // 聊天补全拦截：第一次返回 tool_calls，第二次返回普通文本
    const chatRequests = [];
    let chatRound = 0;
    await page.route('**/chat/completions*', route => {
        const body = route.request().postDataJSON() || {};
        chatRequests.push(body);
        chatRound++;
        if (chatRound === 1) {
            route.fulfill({
                status: 200, contentType: 'application/json',
                body: JSON.stringify({
                    id: 'chatcmpl-e2e-1', object: 'chat.completion', created: 1792300000,
                    choices: [{
                        index: 0,
                        message: {
                            role: 'assistant', content: '',
                            tool_calls: [{
                                id: 'call_e2e_metaso_1', index: 0, type: 'function',
                                function: { name: 'tool_metaso', arguments: JSON.stringify({ query: '李白的代表作', reason: '确认诗作名单' }) }
                            }]
                        },
                        finish_reason: 'tool_calls'
                    }]
                })
            });
        } else {
            route.fulfill({
                status: 200, contentType: 'application/json',
                body: JSON.stringify({
                    id: 'chatcmpl-e2e-2', object: 'chat.completion', created: 1792300001,
                    choices: [{ index: 0, message: { role: 'assistant', content: '李白是唐代诗人，代表作包括《静夜思》。' }, finish_reason: 'stop' }]
                })
            });
        }
    });

    const results = [];
    const check = (name, ok, detail) => {
        results.push({ name, ok, detail: detail || '' });
        console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail ? ' | ' + detail : ''}`);
    };

    const getState = () => page.evaluate(() => {
        const proxy = document.querySelector('#app')._vnode.component.proxy;
        return {
            activeTools: (proxy.activeTools || []).map(t => ({
                id: t.id, name: t.name, type: t.type, callName: t.callName,
                enabled: t.enabled, tavilyApiKey: t.tavilyApiKey || '', metasoApiKey: t.metasoApiKey || ''
            }))
        };
    });

    // 关闭所有可见遮罩（优先点面板内关闭按钮，Escape 兜底）
    const closeOverlays = async () => {
        for (let i = 0; i < 4; i++) {
            const count = await page.locator('.app-modal-overlay:visible').count().catch(() => 0);
            if (!count) return;
            const closeBtn = page.locator('.app-modal-overlay:visible button[aria-label="关闭模型选择"], .app-modal-overlay:visible button.modal-close-button').first();
            if (await closeBtn.count() > 0) {
                await closeBtn.click().catch(() => {});
            } else {
                await page.keyboard.press('Escape').catch(() => {});
            }
            await page.waitForTimeout(350);
        }
        await page.locator('.app-modal-overlay:visible').first().waitFor({ state: 'detached', timeout: 2000 }).catch(() => {});
    };

    await page.goto(BASE, { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(1800);

    // 引导弹窗
    const setupSave = page.locator('.app-modal-overlay button:has-text("保存并开始")').first();
    if (await setupSave.isVisible().catch(() => false)) {
        await page.locator('.app-modal-overlay input[placeholder="角色对您的称呼"]').fill('测试用户');
        await setupSave.click();
        await page.waitForTimeout(600);
    }

    // 预置一个角色卡（聊天需要选中角色，加载时会自动 selectCharacter(0)）
    await page.evaluate(() => window.RPHubStorage.setStoredValue('characters', [{
        name: 'E2E测试角色',
        description: '用于秘塔搜索工具 E2E 测试的角色卡。',
        first_mes: '你好，很高兴见到你。',
        avatar: '',
        personality: '友善',
        mes_example: '',
        uuid: 'e2e-char-uuid-0001',
        createdAt: Date.now(),
        uiTemplates: []
    }]));
    await page.reload({ waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(1800);
    const setupSave2 = page.locator('.app-modal-overlay button:has-text("保存并开始")').first();
    if (await setupSave2.isVisible().catch(() => false)) {
        await page.locator('.app-modal-overlay input[placeholder="角色对您的称呼"]').fill('测试用户');
        await setupSave2.click();
        await page.waitForTimeout(600);
    }

    // 打开工具页（工具为独立视图）
    await page.locator('.app-nav-trigger:visible').first().click();
    await page.waitForSelector('#app-navigation-panel', { state: 'visible', timeout: 3000 });
    await page.locator('#app-navigation-panel button:has-text("工具")').first().click();
    await page.waitForTimeout(900);

    // ========== D1：工具列表默认包含「秘塔联网搜索」 ==========
    const toolsBefore = (await getState()).activeTools;
    const metasoTool = toolsBefore.find(t => t.id === 'tool_metaso');
    check('D1 工具列表默认出现「秘塔联网搜索」',
        !!metasoTool && metasoTool.name === '秘塔联网搜索' && metasoTool.type === 'metaso_search' && metasoTool.callName === 'tool_metaso',
        metasoTool ? `${metasoTool.name} / ${metasoTool.type} / ${metasoTool.callName}` : '未找到');
    // 且不被误判为 Tavily 工具（callName 不能变成 tool_web）
    const webTool = toolsBefore.find(t => t.id === 'tool_web');
    check('D1b Tavily 工具保持独立（callName 仍为 tool_web）',
        !!webTool && webTool.callName === 'tool_web', webTool ? webTool.callName : '未找到');

    // ========== D2：启用秘塔工具 → 出现缺 Key 提示 ==========
    const metasoItem = page.locator('#active-tools-list .sortable-list-item', { hasText: '秘塔联网搜索' }).first();
    await metasoItem.scrollIntoViewIfNeeded().catch(() => {});
    const toggle = metasoItem.locator('input.settings-toggle-input').first();
    await toggle.click({ force: true });
    await page.waitForTimeout(400);
    const hintText = await metasoItem.innerText();
    check('D2 启用后提示「需要填写秘塔 API Key」', hintText.includes('需要填写秘塔 API Key'), hintText.replace(/\s+/g, ' ').slice(0, 80));

    // ========== D3：编辑器显示秘塔 Key 输入（非 Tavily） ==========
    await metasoItem.locator('button.sortable-item-main').first().click();
    await page.waitForTimeout(500);
    const editorOverlay = page.locator('.app-modal-overlay:visible').last();
    const metasoLabel = await editorOverlay.locator('#metaso-api-key').count();
    const tavilyLabel = await editorOverlay.locator('#tavily-api-key').count();
    check('D3 编辑器显示「秘塔 API Key」输入框（而非 Tavily）',
        metasoLabel === 1 && tavilyLabel === 0, `metaso输入框=${metasoLabel} tavily输入框=${tavilyLabel}`);
    await editorOverlay.locator('#metaso-api-key').fill('mk-e2e-metaso-key');
    await page.waitForTimeout(200);
    await editorOverlay.locator('button:has-text("保存工具")').first().click();
    await page.waitForTimeout(500);
    const stAfterSave = await getState();
    const savedMetaso = stAfterSave.activeTools.find(t => t.id === 'tool_metaso');
    check('D3b 秘塔 API Key 保存生效',
        savedMetaso?.enabled === true && savedMetaso?.metasoApiKey === 'mk-e2e-metaso-key',
        `enabled=${savedMetaso?.enabled} key=${savedMetaso?.metasoApiKey}`);
    await closeOverlays();

    // ========== D4：配置 SiliconFlow Key + 模型（供聊天用） ==========
    await closeOverlays();
    await page.locator('.app-nav-trigger:visible').first().click();
    await page.waitForSelector('#app-navigation-panel', { state: 'visible', timeout: 3000 });
    await page.locator('#app-navigation-panel button:has-text("设置")').first().click();
    await page.waitForTimeout(900);
    const keyInput = page.locator('input[placeholder="sk-..."]').first();
    await keyInput.fill('sk-e2e-sf-key');
    await page.locator('button[aria-label="选择聊天模型"]').first().click();
    const modal = page.locator('.model-selector-panel');
    await modal.waitFor({ state: 'visible', timeout: 3000 });
    await page.waitForTimeout(800);
    // quickModels 初始不绑定供应商，需先点供应商栏才会拉取模型
    const providerBar = modal.locator('div[role="group"][aria-label="切换模型供应商"] button:has-text("SiliconFlow")').first();
    if (await providerBar.count() > 0) {
        await providerBar.click();
        await page.waitForTimeout(1500);
    }
    const modelBtn = modal.locator('div[role="group"][aria-label="可选模型"] button').first();
    if (await modelBtn.count() > 0) {
        await modelBtn.click();
        await page.waitForTimeout(400);
    }
    await closeOverlays();

    // ========== D5：聊天发送 → 工具调用全链路 ==========
    await closeOverlays();
    await page.locator('.app-nav-trigger:visible').first().click();
    await page.waitForSelector('#app-navigation-panel', { state: 'visible', timeout: 3000 });
    await page.locator('#app-navigation-panel button:has-text("聊天")').first().click();
    await page.waitForTimeout(800);

    await page.locator('textarea.island-input').first().fill('李白有哪些代表作？');
    await page.locator('button.island-send').first().click();

    // 等待工具执行与自动继续完成（第二次 chat 请求 + 最终回复）
    let finalReply = '';
    for (let i = 0; i < 60; i++) {
        const bodyText = await page.locator('#app').innerText().catch(() => '');
        if (bodyText.includes('李白是唐代诗人，代表作包括《静夜思》。')) { finalReply = 'ok'; break; }
        await page.waitForTimeout(250);
    }
    check('D5 AI 最终回复展示（工具调用后自动继续）', finalReply === 'ok', finalReply || '未出现最终回复');

    // 秘塔 API 调用断言
    const metasoCall = metasoRequests[0];
    check('D6 秘塔 API 调用正确（URL / Bearer Key / question）',
        !!metasoCall
        && metasoCall.url === 'https://metaso.cn/api/open/search/v2'
        && metasoCall.auth === 'Bearer mk-e2e-metaso-key'
        && metasoCall.body.question === '李白的代表作'
        && metasoCall.body.stream === false,
        metasoCall ? `${metasoCall.url} | ${metasoCall.auth} | q=${metasoCall.body.question}` : '未调用');

    // 工具定义注册断言（第一次请求体）
    const firstReq = chatRequests[0];
    const toolDefs = firstReq?.tools || [];
    const metasoDef = toolDefs.find(t => t.function?.name === 'tool_metaso');
    check('D7 请求体注册 tool_metaso 工具定义',
        !!metasoDef && metasoDef.function.description.includes('秘塔'),
        metasoDef ? metasoDef.function.description.slice(0, 50) : '未注册');

    // 工具结果回传断言（第二次请求体含 tool 消息）
    const secondReq = chatRequests[1];
    const toolMsg = (secondReq?.messages || []).find(m => m.role === 'tool');
    let toolPayload = null;
    try { toolPayload = toolMsg ? JSON.parse(toolMsg.content) : null; } catch (e) {}
    check('D8 工具结果回传（AI 整合答案 + 来源链接）',
        !!toolPayload && toolPayload.status === 'ok'
        && Array.isArray(toolPayload.results)
        && toolPayload.results.some(r => r.title === '秘塔 AI 整合答案' && r.content.includes('李白是唐代著名诗人'))
        && toolPayload.results.some(r => r.url === 'https://baike.baidu.com/item/libai'),
        toolPayload ? `status=${toolPayload.status} 条数=${toolPayload.results?.length}` : '无 tool 消息');

    // UI 展示断言：工具调用卡片显示「秘塔联网搜索」
    const uiText = await page.locator('#app').innerText().catch(() => '');
    check('D9 聊天界面工具卡片显示「秘塔联网搜索」', uiText.includes('秘塔联网搜索'), '');

    console.log('\n================ 汇总 ================');
    const pass = results.filter(r => r.ok).length;
    const fail = results.filter(r => !r.ok).length;
    results.forEach(r => console.log(`${r.ok ? 'PASS' : 'FAIL'} | ${r.name}${r.detail ? ' | ' + r.detail : ''}`));
    console.log(`\n总计 ${results.length} 项：通过 ${pass}，失败 ${fail}`);
    if (errors.length) {
        console.log('\n---- 页面错误 ----');
        errors.slice(0, 10).forEach(e => console.log(e));
    }
    await browser.close();
    process.exit(fail > 0 ? 1 : 0);
})().catch(e => { console.error('E2E 脚本异常:', e); process.exit(2); });
