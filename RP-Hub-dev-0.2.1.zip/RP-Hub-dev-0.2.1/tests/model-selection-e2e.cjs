/* E2E：聊天页面模型选择 + 记忆系统模型选择（多供应商链路打通验证） */
const { chromium } = require('playwright');

const BASE = 'http://localhost:8899/index.html';
const FAKE_MODELS = {
    object: 'list',
    data: [
        { id: 'e2e-model-alpha', object: 'model', owned_by: 'e2e' },
        { id: 'e2e-model-beta', object: 'model', owned_by: 'e2e' }
    ]
};

(async () => {
    const browser = await chromium.launch();
    const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
    const errors = [];
    page.on('pageerror', e => errors.push('[pageerror] ' + e.message));
    page.on('console', m => { if (m.type() === 'error') errors.push('[console] ' + m.text()); });

    await page.addInitScript(() => {
        try { localStorage.setItem('roleplay_hub_update_id', '99999'); } catch (e) {}
    });
    // 拦截所有供应商的 /v1/models 请求，返回伪造模型列表
    let modelsRequestCount = 0;
    await page.route('**/v1/models*', route => {
        modelsRequestCount++;
        route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(FAKE_MODELS) });
    });

    const results = [];
    const check = (name, ok, detail) => {
        results.push({ name, ok, detail: detail || '' });
        console.log(`${ok ? 'PASS' : 'FAIL'} | ${name}${detail ? ' | ' + detail : ''}`);
    };

    const getState = () => page.evaluate(() => {
        const container = document.querySelector('#app');
        const proxy = container._vnode.component.proxy;
        return {
            apiProviderId: proxy.settings.apiProviderId,
            qualityModel: proxy.settings.qualityModel,
            balancedModel: proxy.settings.balancedModel,
            fastModel: proxy.settings.fastModel,
            model: proxy.settings.model,
            slotProviders: { ...proxy.settings.slotProviders },
            currentModelMode: proxy.currentModelMode,
            modelMode: proxy.modelMode,
            classicModel: proxy.memorySettings.classicModel,
            classicProviderId: proxy.memorySettings.classicProviderId,
            embeddingModel: proxy.memorySettings.embeddingModel,
            embeddingProviderId: proxy.memorySettings.embeddingProviderId
        };
    });

    await page.goto(BASE, { waitUntil: 'networkidle' });
    await page.waitForTimeout(2000);

    // 处理首次用户引导
    const setupSave = page.locator('button:has-text("保存并开始")').first();
    if (await setupSave.isVisible().catch(() => false)) {
        await page.locator('.app-modal-overlay input[placeholder="角色对您的称呼"]').fill('测试用户');
        await setupSave.click();
        await page.waitForTimeout(600);
    }

    const openNav = async (label) => {
        await page.locator('.app-nav-trigger:visible').first().click();
        await page.waitForSelector('#app-navigation-panel', { state: 'visible', timeout: 3000 });
        await page.locator(`#app-navigation-panel button:has-text("${label}")`).first().click();
        await page.waitForTimeout(700);
    };

    // ========== 准备：为 sta1n 与 deepseek 两个供应商各配一个 Key ==========
    await openNav('设置');
    const keyInput = page.locator('input[placeholder="sk-..."]').first();
    await keyInput.fill('sk-e2e-sta1n-key');
    // 切换到 DeepSeek（selectApiProvider 会先把 sta1n 的 Key 同步落库）
    const trigger = page.locator('.api-provider-selector-container > button.settings-control').first();
    await trigger.click();
    await page.locator('.api-provider-selector-container div.absolute button:has-text("DeepSeek")').first().click();
    await page.waitForTimeout(400);
    await keyInput.fill('sk-e2e-deepseek-key');
    await page.waitForTimeout(300);
    let st = await getState();
    check('双供应商 Key 就绪', st.apiProviderId === 'deepseek', '当前供应商=' + st.apiProviderId);

    // ========== 流程 A：聊天模型（quickModels 三槽位 + 供应商切换） ==========
    await page.locator('button[aria-label="选择聊天模型"]').first().click();
    const modal = page.locator('.model-selector-panel');
    await modal.waitFor({ state: 'visible', timeout: 3000 });
    const providerBar = modal.locator('div[role="group"][aria-label="切换模型供应商"]');
    check('A1 选择器打开-供应商栏可见', await providerBar.count() === 1);

    // 切到 DeepSeek → 应触发模型拉取（被拦截）并渲染列表
    await providerBar.locator('button:has-text("DeepSeek")').click();
    await page.waitForTimeout(1200);
    const modelButtons = modal.locator('div[role="group"][aria-label="可选模型"] button');
    const modelCount = await modelButtons.count();
    check('A2 切换供应商后拉取并渲染模型列表', modelCount === 2, '模型按钮数=' + modelCount + '，models 请求次数=' + modelsRequestCount);

    // 槽位1 选择 alpha（供应商 DeepSeek）
    await modelButtons.filter({ hasText: 'e2e-model-alpha' }).first().click();
    await page.waitForTimeout(300);
    st = await getState();
    check('A3 槽位1绑定 DeepSeek + alpha',
        st.qualityModel === 'e2e-model-alpha' && st.slotProviders.quality === 'deepseek',
        `qualityModel=${st.qualityModel}, slotProviders.quality=${st.slotProviders.quality}`);

    // 激活槽位2（未绑定供应商 → 列表清空），再切到 STA1N → 重新拉取
    const reqBeforeSlot2 = modelsRequestCount;
    await modal.locator('div[role="group"][aria-label="聊天模型槽位"] button').nth(1).click();
    await page.waitForTimeout(400);
    check('A4 激活未绑定槽位后列表清空', await modelButtons.count() === 0,
        '模型按钮数=' + await modelButtons.count());
    await providerBar.locator('button:has-text("STA1N API")').click();
    await page.waitForTimeout(1200);
    check('A5 槽位2切换 STA1N 再次拉取模型', modelsRequestCount > reqBeforeSlot2 && await modelButtons.count() === 2,
        `请求 ${reqBeforeSlot2} -> ${modelsRequestCount}，模型按钮数=${await modelButtons.count()}`);
    // 槽位2 选择 beta（供应商 STA1N）
    await modelButtons.filter({ hasText: 'e2e-model-beta' }).first().click();
    await page.waitForTimeout(300);
    st = await getState();
    check('A6 槽位2绑定 STA1N + beta',
        st.balancedModel === 'e2e-model-beta' && st.slotProviders.balanced === 'sta1n',
        `balancedModel=${st.balancedModel}, slotProviders.balanced=${st.slotProviders.balanced}`);
    await page.keyboard.press('Escape');
    await page.waitForTimeout(400);

    // ========== 流程 B：聊天页面快捷面板（槽位展示供应商名 + 切换槽位） ==========
    await openNav('聊天');
    const quickPanelBtn = page.locator('button[aria-label="快捷面板"]');
    await quickPanelBtn.click();
    const quickPanel = page.locator('#chat-quick-panel');
    await quickPanel.waitFor({ state: 'visible', timeout: 3000 });
    const slotButtons = quickPanel.locator('.chat-model-slots button');
    const slot1Text = await slotButtons.nth(0).innerText();
    check('B1 快捷面板槽位1显示模型+供应商名',
        slot1Text.includes('e2e-model-alpha') && slot1Text.includes('DeepSeek'),
        '槽位1文本=' + slot1Text.replace(/\n/g, ' / '));
    // 点击槽位2 → 切换到 balanced 模式
    await slotButtons.nth(1).click();
    await page.waitForTimeout(400);
    st = await getState();
    const slot2Pressed = await slotButtons.nth(1).getAttribute('aria-pressed');
    check('B2 点击槽位2切换到 balanced 模式',
        st.modelMode === 'balanced' && st.model === 'e2e-model-beta' && slot2Pressed === 'true',
        `mode=${st.modelMode}, model=${st.model}, aria-pressed=${slot2Pressed}`);
    await page.keyboard.press('Escape');
    await page.locator('body').click({ position: { x: 5, y: 5 } });
    await page.waitForTimeout(300);

    // ========== 流程 C：记忆系统模型选择（总结模型 + 向量模型独立供应商） ==========
    await openNav('记忆系统');
    const collapseTrigger = page.locator('.settings-collapse-trigger:has-text("记忆系统设置")').first();
    if (await collapseTrigger.getAttribute('aria-expanded') !== 'true') {
        await collapseTrigger.click();
        await page.waitForTimeout(500);
    }
    const memToggle = page.locator('#memory-settings-panel input.settings-toggle-input').first();
    if (!(await memToggle.isChecked())) { await memToggle.click({ force: true }); await page.waitForTimeout(500); }

    // 总结模型
    await page.locator('button[title="请选择总结模型"]').first().click();
    await modal.waitFor({ state: 'visible', timeout: 3000 });
    // 当前供应商为 deepseek（apiProviderId），其模型已缓存，列表应直接出现
    await page.waitForTimeout(600);
    const memModelButtons = modal.locator('div[role="group"][aria-label="可选模型"] button');
    check('C1 记忆总结模型选择器打开即有模型列表（供应商缓存命中）',
        await memModelButtons.count() === 2, '模型按钮数=' + await memModelButtons.count());
    // 切到 STA1N 供应商再选 beta
    await providerBar.locator('button:has-text("STA1N API")').click();
    await page.waitForTimeout(1200);
    await memModelButtons.filter({ hasText: 'e2e-model-beta' }).first().click();
    await page.waitForTimeout(400);
    st = await getState();
    check('C2 总结模型绑定 STA1N + beta',
        st.classicModel === 'e2e-model-beta' && st.classicProviderId === 'sta1n',
        `classicModel=${st.classicModel}, classicProviderId=${st.classicProviderId}`);
    // 页面提示同步
    const classicHint = page.locator('#memory-settings-panel div:has-text("供应商：")').first();
    check('C3 总结模型供应商提示同步', (await classicHint.innerText()).includes('STA1N API'),
        (await classicHint.innerText()).trim().split('\n').pop());

    // 向量模型（增强模式）
    await page.locator('#memory-settings-panel button[aria-label="切换到增强模式"]').first().click();
    await page.waitForTimeout(500);
    await page.locator('button[title="请选择向量模型"]').first().click();
    await modal.waitFor({ state: 'visible', timeout: 3000 });
    await page.waitForTimeout(600);
    // embedding 目标不过滤，直接用当前 sta1n 缓存
    const embButtons = modal.locator('div[role="group"][aria-label="可选模型"] button');
    check('C4 向量模型选择器打开即有模型列表', await embButtons.count() === 2,
        '模型按钮数=' + await embButtons.count());
    await embButtons.filter({ hasText: 'e2e-model-alpha' }).first().click();
    await page.waitForTimeout(400);
    st = await getState();
    check('C5 向量模型绑定 sta1n + alpha',
        st.embeddingModel === 'e2e-model-alpha' && st.embeddingProviderId === 'sta1n',
        `embeddingModel=${st.embeddingModel}, embeddingProviderId=${st.embeddingProviderId}`);
    const embHint = page.locator('#memory-settings-panel div:has-text("供应商：")').nth(1);
    check('C6 向量模型供应商提示同步', (await embHint.innerText()).includes('STA1N API'),
        (await embHint.innerText()).trim().split('\n').pop());

    check('C7 全程无 JS 错误', errors.length === 0, errors.slice(0, 5).join(' ; ') || '0 errors');

    await page.screenshot({ path: '/tmp/verify-e2e.png' });
    await browser.close();

    const failed = results.filter(r => !r.ok);
    console.log('\n==== 汇总: ' + (results.length - failed.length) + '/' + results.length + ' 通过 ====');
    failed.forEach(f => console.log('未通过: ' + f.name + ' | ' + f.detail));
    process.exit(failed.length ? 1 : 0);
})().catch(e => { console.error('脚本异常:', e); process.exit(2); });
