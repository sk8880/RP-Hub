# RP-Hub Dev 2.0.5 改动说明

本版本基于上游 **RP-Hub 2.0.3** 制作，是个人自用的定制分支。与上游相比的改动分为四类：本地化依赖、HTML 卡片兼容、安全加固、版本号。

## 1. 本地化依赖（可完全离线）

- 新增 `assets/vendor/`，Vue、Tailwind、marked、DOMPurify、Sortable、jQuery、daisyUI 全部改为本地文件；页面不再请求 jsdelivr / unpkg 等 CDN。
- 字体改为 `assets/vendor/fonts/local-fonts.css`：用 `font-family` 映射到本机已安装的同类字体，不再请求 fonts.googleapis.com。
- `assets/vendor/README.md` 记录了每个文件的作用与来源，想换回官方 dist 时直接替换同名文件即可。

## 2. HTML 卡片兼容层（重点）

上游的 HTML 卡片（含 `<!doctype html>` 的整页消息、```html 代码块、脚本面板）依赖父页面读取 iframe 内容，无法在“无同源权限的沙箱”里工作。本版本改为下面的方案：

- 卡片在 `sandbox="allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-downloads allow-pointer-lock allow-presentation"` 的 iframe 中运行。**移除了 `allow-same-origin`**：卡片拿不到父页面的 DOM、localStorage 和 Cookie，因此卡片里的任意脚本无法读到 API 密钥。
- 卡片的以下能力改为 `postMessage` 回传主页面，由主页面代为执行：
  - **自动高度**：`RPHUB_FRAME_HEIGHT`，带 ResizeObserver 和 1 秒轮询兜底；主页面只接受来自本页卡片 iframe 的消息。
  - **斜杠指令**：卡片里的 `triggerSlash()` 或带 `data-slash` 的元素会发送 `RPHUB_FRAME_SLASH`，由主页面照常执行斜杠指令。
  - **记忆引用**：卡片正文中的 `[M12]` / `[M12, M15]` 会被自动装饰成可点击的引用按钮，点击后发送 `RPHUB_CITE_OPEN`，主页面打开对应的记忆。
- 完整 HTML 文档（`<!doctype html>`）、带 `<head>` 的片段、裸片段三种形态都能正确注入本地 jQuery 和桥接脚本，不会因为缺 `<head>`/`<body>` 而错位。
- 卡片中 `window.jQuery` 缺失时，桥接脚本会注入一个极简的 jQuery 兜底（`$()`、`on/off`、`attr`、`addClass`、`html/text` 等常用方法），避免卡片脚本直接报错。

> 注意：因为去掉了 `allow-same-origin`，卡片里**访问 `parent.document`、父页面 `localStorage` 或自带 `fetch` 跨域读取本地数据**的写法不再可用。需要与主页面交互时请使用上面的三个消息，或回到“把内容当普通 Markdown 渲染”的方式。

## 3. 安全加固（个人使用威胁模型）

- 主页面 → 工作台（角色卡工坊）的设置同步不再整包外发：只发送工作台真正需要的字段（接口地址、服务商、生图设置、模型名等），**API Key 不再随同源消息发送**；消息目标也由 `'*'` 改为 `location.origin`。
- 所有内嵌页面之间的消息（`WORKSHOP_READY`、`WORKSHOP_IMPORT_AND_PLAY`、`REQUEST_RPHUB_API_SETTINGS`、主题同步等）都加上了来源校验：只接受本页同源（`file://` 下的 `null` 视为同源），回复也不再使用 `'*'`。
- 工作台的设置监听同时校验来源，并且 API Key 缺失时回落到所选服务商的密钥。
- 消息渲染器的 DOMPurify 配置收紧：宿主文档不再放行 `<script>`、`srcdoc`、`sandbox`、内联 `onclick` 等属性；卡片脚本仍然只在沙箱 iframe 中执行。
- `presence-server`（可选的更新检测服务）默认 **拒绝所有跨域来源**：只有设置了 `ALLOWED_ORIGINS` 白名单（或显式写 `*`）才放行；`file://` 页面的 `Origin: null` 只回 `Access-Control-Allow-Origin: null`，不会顺带放开其他网站。详见 `presence-server/README.md`。

## 4. 版本号

- `index.html` 的 `rphub-dev-version`、页面标题与版权注释均更新为 **2.0.5**（上游基线保持 2.0.3）。
- 远程更新检测保持关闭，页面不会向你推送上游版本提醒。

## 未包含的改动

- 没有移植 0.1.x 分支的“多密钥槽位”“provider 级模型选择”“导入导出备份”等功能：2.0.3 本身没有这些实现，两者是不同分支。
- 没有修改聊天、记忆、工具调用等业务逻辑。
