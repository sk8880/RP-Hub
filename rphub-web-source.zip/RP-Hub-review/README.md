# RP-Hub custom webpage source

Version: v2.5 (2026-10-08)

This package contains the repaired RP-Hub custom webpage source, including main chat multi-key/model-slot binding and memory model selector search fixes.
