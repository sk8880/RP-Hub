# RP-Hub custom webpage source

Version: v2.6 (2026-10-09)

This package contains the repaired RP-Hub custom webpage source, including main chat multi-key/model-slot binding and memory model selector search fixes.

## v2.6 changes

- Added merge and replace modes for backup import, with backup type/version validation.
- Added SillyTavern-style preset import from a `prompts` array; non-empty prompt content is imported and empty items are skipped.
- Mapped SillyTavern `role` values to RP-Hub preset role types; unsupported injection position/depth controls are ignored.
- Renamed the preset editor field label from “注入位置” to “角色类型”.
