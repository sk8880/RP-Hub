# RP-Hub 项目结构与审核说明

> 审核对象：`RP-Hub-custom.zip` 解压后的 `RP-Hub-review/`，README 标记版本 v2.6（2026-10-09）。本说明依据源码静态检查整理；未运行浏览器端到端测试，也未逐行审计所有业务代码。

## 1. 项目概览

这是一个以原生 HTML/CSS/JavaScript + Vue 3 全局构建版组成的静态单页应用，面向角色扮演聊天、角色卡管理、小说生成与记忆管理。没有 package.json、构建脚本或服务端源码；主站通过静态文件直接提供。应用调用用户配置的 OpenAI 兼容 API 等外部服务。

## 2. 目录树

```text
RP-Hub-review/
├── index.html                    主聊天应用：页面骨架、导航、模态框，加载业务模块
├── README.md                     版本与打包说明
├── STRUCTURE.md                  本结构说明及审核摘要
├── character/
│   └── index.html                角色卡工坊：角色资料编辑、导入导出、预览
├── novel/
│   └── index.html                小说生成页面：独立 Vue 应用及本地项目存储
└── assets/
    ├── css/
    │   ├── styles.css            主站布局、组件与响应式样式
    │   └── theme.css             主题变量与主题同步样式
    ├── js/
    │   ├── theme.js              主题读写、同源 iframe 主题同步
    │   ├── built-in-content.js   内置提示词、预设、默认内容与版本信息
    │   ├── core-utils.js         通用工具、配置、角色卡/PNG 解析与导出等
    │   ├── api-utils.js          API 地址构造、JSON 与流式聊天请求
    │   ├── data-services.js      IndexedDB、数据规范化、记忆/上下文/分支/UI 模板工具
    │   ├── runtime-services.js   消息渲染、Token 用量与存储管理 composable
    │   ├── presence.js            在线状态/Presence composable（独立模块）
    │   ├── update-check.js        可选远端版本检查 composable
    │   ├── ui-components.js       Vue 组件、导航、弹窗与选择器注册
    │   └── app.js                 主应用状态、业务编排、聊天/记忆/工具等逻辑
    └── vendor/                    随包附带的第三方前端依赖
        ├── vue.global.prod.js     Vue 3
        ├── tailwind.js            Tailwind 浏览器版
        ├── daisyui.min.css        DaisyUI 样式
        ├── marked.min.js          Markdown 解析
        ├── purify.min.js          DOMPurify HTML 清理
        ├── Sortable.min.js        列表拖拽
        └── localforage.min.js     角色卡工坊本地存储适配
```

## 3. 页面与加载关系

### 主页面 `index.html`

页面先载入主题脚本、Tailwind、Vue、Marked、DOMPurify、Sortable；HTML 中提供 Vue 挂载点 `#app`、导航与各类模态框。页尾按依赖顺序动态加载：

```text
built-in-content → core-utils → api-utils → data-services
→ runtime-services → update-check → ui-components → app
```

`app.js` 读取前序脚本挂到 `window` 的 `RPHub*` 命名空间，创建 Vue 应用并挂载。HTML 与业务 JS 分离有限：主页面 HTML 本身较大，仍内嵌大量模板结构。

### `character/index.html`

独立 Vue 页面「角色卡工坊」，复用主题、内置内容、核心/API 工具和 Vue；用 localforage 将角色数据存入浏览器 IndexedDB，支持角色编辑、导入导出、预览等。

### `novel/index.html`

独立 Vue 页面「小说生成」，复用主题、内置内容、核心/API 工具；通过 IndexedDB 保存小说项目及相关数据。页面大量模板和逻辑仍内嵌在单个 HTML 文件中。

## 4. 主要模块职责

| 模块 | 主要职责 |
|---|---|
| `built-in-content.js` | 内置 prompt、预设、默认工具/角色内容与更新数据；导出 `RPHubBuiltinContent`、`RPHubBuiltinPresets` 等。 |
| `core-utils.js` | 文本/思维标签解析、API 错误与用量归一化、角色卡结构转换、PNG 元数据读写、默认配置；导出 `RPHubUtils`、`RPHubCardUtils`、`RPHubConfig`。 |
| `api-utils.js` | 统一 API endpoint，处理 JSON 请求、超时/取消与 SSE 流式补全；导出 `RPHubApiClient`、`RPHubApiUtils`。 |
| `data-services.js` | IndexedDB 持久化与旧库兼容；记忆向量、世界信息、会话上下文、故事分支及 UI 模板处理；导出多个 `RPHub*` 服务。 |
| `runtime-services.js` | Markdown/消息渲染、Token 统计、存储统计、清理及备份恢复 composable。 |
| `ui-components.js` | 导航、表单、列表、编辑器、提示框与各类弹窗 Vue 组件。 |
| `app.js` | 主应用总控：配置与状态、角色/对话管理、供应商模型、聊天生成、工具调用、记忆、图片及 UI 模板等。 |
| `presence.js` | Presence 请求逻辑；本次静态检索未发现主页面调用点，需确认是否为遗留/外部页面使用。 |
| `update-check.js` | 根据 HTML meta 配置可选检查远端版本；组件调用 `useUpdateCheck()`。 |

## 5. 数据与网络路径

- 主站 IndexedDB 主库名称为 `RPHubDB`（由 `data-services.js` 管理），逻辑键使用 `rp_hub_` 前缀，并尝试兼容旧库/旧键。主站 localStorage 亦用于少量偏好/索引信息。
- 预设导入支持 RP-Hub JSON 数组/单对象，以及含 `prompts` 数组的 SillyTavern 风格 JSON；后者仅导入 `content` 非空的 prompt，空项跳过，并将 ST `role` 映射为 RP 角色类型。ST 的 `injection_position`/`injection_depth` 不映射；RP 此处没有深度插入功能。预设编辑器字段称为“角色类型”。
- 角色工坊配置 localforage 数据库 `AICharGen`，使用 localStorage 保存当前角色索引。
- 小说页另行打开 IndexedDB `RPHubDB`，自身实现数据库访问；建议核对其对象仓库/版本与主站保持兼容。
- API 请求由 `api-utils.js` 与 `app.js` 发出，认证密钥以 `Authorization: Bearer ...` 传给配置的 API 服务。密钥属于浏览器本地数据，不应在共享设备或导出的备份中无保护传播。
- `runtime-services.js` 提供全量 IndexedDB + localStorage JSON 备份/恢复；导入时可选择合并（保留本机独有项，备份同名键覆盖）或清空后导入，来源应可信。

## 6. 审核发现与建议

### 高优先级：可执行 HTML iframe 权限过宽

`data-services.js` 的 `htmlIframeSandbox` 同时允许 `allow-scripts` 与 `allow-same-origin`，并含表单、弹窗、下载、指针锁定及用户触发的顶层导航权限。由聊天消息/模板生成的 HTML 会经此路径写入 `iframe.srcdoc`，还会注入 CDN jQuery。虽然 iframe 使用 sandbox，脚本 + same-origin 组合会显著削弱隔离效果；若不可信模型输出可触发同源访问风险，必须视为主要安全边界问题。

建议：默认移除 `allow-same-origin`；按实际需要逐项收紧 sandbox 能力；不要向不可信 HTML 暴露父页面敏感数据或可调用接口；外链资源采用明确白名单/禁用策略；对可执行 HTML 设置显式用户确认与关闭选项，并测试导入内容和模型输出路径。

### 高优先级：HTML 输出渲染面需逐处复核

`runtime-services.js` 的 Markdown 结果存在 DOMPurify 清理流程，但主 UI 也有多个 `v-html` 接口，渲染源包括更新内容、消息正文、模板预览及提示信息。需逐条确认传入内容已清理、DOMPurify 配置不会允许危险事件属性/URL；例如自定义清理配置允许 `onclick` 属性，应评估其必要性。不要仅因某一渲染器使用 sanitizer 就认为所有 `v-html` 安全。

### 中优先级：跨窗口消息

`app.js` 中有针对部分 iframe 的 `event.source` 与 `event.origin` 校验，属于正向措施；仍有 `postMessage(..., '*')` 发送点。建议优先使用精确 origin，并为所有消息增加严格来源、数据类型、字段和请求状态校验；不要把 API 密钥发往不受信任的 iframe。对 `theme.js` 同源限制也应维持。

### 中优先级：敏感信息备份与浏览器持久化

API Key、角色/对话及配置保存在浏览器本地，并能随全量备份导出。建议备份前明确提示其可能包含密钥与私人内容，可选剔除密钥或加密；恢复时限制可写键前缀、验证数据结构与大小，避免恶意备份覆盖非应用存储项。

### 维护性与可靠性

- 多个页面和 `app.js`/`ui-components.js` 体积较大，建议按功能拆分、建立依赖/数据格式文档与自动化测试。
- `index.html` 用 `document.write` 加时间戳动态加载 CSS/JS：有利于避免旧缓存，但不利于 CSP、缓存复用和故障定位；可改为显式 script/link 与版本化构建产物。
- ZIP 完整性检查通过；当前没有发现压缩数据损坏。静态检查不能替代运行时测试、第三方依赖版本核验或完整安全审计。

## 7. 建议的后续验证清单

1. 在隔离测试浏览器中测试主聊天、API 流式输出、取消请求、记忆与分支持久化。
2. 使用无害的 HTML 安全测试样本确认 iframe 无法访问父页面 DOM、localStorage、API Key 或发起未授权顶层跳转。
3. 检查所有 `v-html` 输入来源及 DOMPurify 配置，验证 `javascript:` URL、事件属性、SVG/MathML 与嵌套 iframe 的处理。
4. 测试跨源 iframe 消息拒绝、备份导出/恢复、损坏数据恢复和旧数据库迁移。
5. 记录 vendor 依赖的准确版本、来源与许可；建立哈希/更新流程。
