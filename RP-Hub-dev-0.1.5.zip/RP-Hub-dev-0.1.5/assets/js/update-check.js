// Dev 0.1.5: remote update detection intentionally disabled.
// Preserve the component interface without fetch, timers or visibility listeners.
(function () {
    window.RPHubUpdateCheck = Object.freeze({ useUpdateCheck() {} });
})();
