# Dev 0.1.5

基于 Dev 0.1.4，核心改动为**记忆系统多供应商**与**模型列表隔离**：

## 记忆系统模型独立绑定供应商
- `memorySettings` 新增 `classicProviderId`（总结模型）、`embeddingProviderId`（向量模型）。
- 记忆的「总结模型」与「向量模型」各自可单独选择供应商与 Key，不再强制使用主 API 供应商：
  - `requestClassicMemoryCompletion` 通过 `resolveProviderApiContext(memorySettings.classicProviderId || 主供应商)` 取地址/Key，并透传 providerId 给 `requestTrackedChatCompletion`。
  - `requestMemoryEmbeddings` 同理改用 `embeddingProviderId` 的上下文；记忆存储的 `embeddingApiUrl` 与所选供应商保持一致，避免向量索引与检索错位。
  - 记忆区内两个模型按钮下方显示「供应商：XXX」提示，直观看到每个模型挂在哪个供应商。
- 兼容旧数据：未单独绑定（字段为空）时自动回退到主聊天供应商，与原行为一致。
- 切换供应商 / 模型 / 模式仍会终止正在进行的批量记忆任务（`watch` 已纳入两个 ProviderId 字段）。

## 模型选择器按供应商隔离
- 新增 `providerModels`（providerId → 模型列表）缓存；`fetchModels` 不论是否带 context 都按供应商单独存储。
- `selectorModels` 只返回**当前所选供应商**的模型：`selectorProviderId || 目标绑定供应商 || 主供应商`；主供应商在本地列表为空时回退到已缓存的 `availableModels`，避免空列表。
- 修复现象：此前切换供应商标签时，不同供应商的模型会被塞进同一列表；现在切到哪家就只看哪家的模型。

## 版本
- VERSION / 入口 meta（`rphub-dev-version`）/ 标题 已更新为 0.1.5。
- 这是源码包，不是已构建 APK。

## 使用提示
- 先在「API 连接与服务」里把硅基流动和你的第三方供应商都配好 Key，再进记忆系统分别给「总结模型」「向量模型」选供应商。
- 记忆走错供应商（如把总结模型发到 ali 中转报「无可用渠道」）现已解决：请确认记忆模型按钮下方显示的供应商是否正确。
