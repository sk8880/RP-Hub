const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../assets/js/runtime-services.js'),'utf8');
function db(data={},fail=[]){
 const d={data:new Map(Object.entries(data)),writes:0,n:0};
 d.transaction=(_,mode)=>{
  const tx={},ops=[]; let aborted=false;
  tx.abort=()=>{aborted=true};
  tx.objectStore=()=>({clear:()=>ops.push(['clear']),put:(v,k)=>ops.push(['put',k,structuredClone(v)]),openCursor:()=>{
   const req={},rows=[...d.data];let i=0;
   const next=()=>setImmediate(()=>{req.result=i<rows.length?{key:rows[i][0],value:structuredClone(rows[i++][1]),continue:next}:null;req.onsuccess?.();if(!req.result)setImmediate(()=>tx.oncomplete?.());});next();return req;
  }});
  if(mode==='readwrite'){const n=++d.n;setImmediate(()=>{if(aborted||fail.includes(n)){tx.error=new Error('injected DB failure');tx.onabort?.();return;}const next=new Map(d.data);ops.forEach(([op,k,v])=>op==='clear'?next.clear():next.set(k,v));d.data=next;d.writes++;tx.oncomplete?.();});}
  return tx;
 };return d;
}
function setup({failDb=[],failLegacy=[],failSet=0,failRead=false,beforeImport=async()=>{}}={}){
 const main=db({rp_hub_characters:[{name:'original'}],rp_hub_unique:'keep'},failDb),legacy=db({silly_tavern_chat_old:[{content:'old'}]},failLegacy);
 const local=new Map([['unrelated','keep'],['theme','original']]),notes=[],prompts=[],elements=[],downloads=[];let sets=0,writes=0,inits=0;
 const s={Vue:{reactive:x=>x,ref:x=>({value:x}),computed:f=>({value:f()}),watch(){}},window:{location:{reload(){}}},Blob,ArrayBuffer,structuredClone,console:{error(){}},setTimeout(){},
 URL:{createObjectURL:b=>{downloads.push(b);return 'blob:test'},revokeObjectURL(){}},
 localStorage:{get length(){if(failRead)throw Error('injected localStorage read');return local.size},key:i=>[...local.keys()][i]??null,getItem:k=>local.get(k)??null,clear(){writes++;local.clear()},removeItem(k){writes++;local.delete(k)},setItem(k,v){if(++sets===failSet)throw Error('injected localStorage write');writes++;local.set(k,v)}},
 document:{body:{appendChild(){}},createElement(tag){const e={tag,style:{},remove(){},click(){}};elements.push(e);return e;}},
 FileReader:class{readAsText(file){this.result=file.text;this.onload()}}
 };
 vm.runInNewContext(source,s);
 const api=s.window.RPHubComposables.useStorageManagement({beforeImport,characters:{value:[]},globalUiTemplates:{value:[]},scopedStorageNames:['chat','classic_memories','branches'],confirm:(...args)=>prompts.push(args),toast:(...args)=>notes.push(args),ensureStorage:async()=>{inits++},getMainDb:()=>main,getLegacyDb:()=>legacy,getStorageLogicalKey:k=>k.replace(/^(rp_hub_|silly_tavern_)/,''),scanStorageEntries:async(d,src,fn)=>{for(const[k,v]of d.data)fn(src,k,v)},readStorageKeys:async d=>[...d.data.keys()],saveStoredValue:async()=>{throw Error('must use batch commits')},deleteStorageKeys:async()=>{},getBranchOwnerId:x=>x});
 return {api,main,legacy,local,notes,prompts,downloads,get writes(){return writes},get inits(){return inits},load(payload){api.importBackup();const e=elements.findLast(e=>e.tag==='input');e.files=[{text:typeof payload==='string'?payload:JSON.stringify(payload)}];e.onchange()},async apply(mode){const p=prompts.shift();assert.ok(p);if(mode==='replace'){p[1]();await prompts.shift()[1]()}else await p[2]()}};
}
const backup=(entries,localStorage={})=>({type:'rp-hub-backup',version:1,entries,localStorage,exportedAt:'2026-01-01T00:00:00Z'});
const snapshot=h=>JSON.stringify([[...h.main.data],[...h.legacy.data],[...h.local]]);
test('invalid JSON/schema never mutates or initializes storage',()=>{
 for(const input of [null,[], '{bad',backup({characters:'bad'}),backup({settings:[]}),backup({chat_a:['bad']}),backup({branches_a:{branches:'bad'}}),backup({characters:[]},{x:3}),{...backup({characters:[]}),localStorage:[]},{...backup({characters:[]}),exportedAt:'bad'},backup({last_active_char:0.5}),backup({rp_hub_characters:[]}),backup({characters:[JSON.parse('{"__proto__":{}}')]}),backup({})]){
  const h=setup(),before=snapshot(h);h.load(input);assert.equal(snapshot(h),before);assert.equal(h.inits,0);assert.equal(h.main.writes+h.legacy.writes+h.writes,0);assert.equal(h.prompts.length,0);assert.equal(h.notes.at(-1)[1],'error');
 }
});
test('merge overrides matching records but preserves unique main, legacy and origin keys',async()=>{
 const h=setup();h.load(backup({characters:[{name:'imported'}],custom:'new'},{theme:'imported'}));assert.match(h.prompts[0][0],/localStorage/);await h.apply('merge');assert.equal(h.main.data.get('rp_hub_characters')[0].name,'imported');assert.equal(h.main.data.get('rp_hub_unique'),'keep');assert.ok(h.legacy.data.has('silly_tavern_chat_old'));assert.equal(h.local.get('unrelated'),'keep');assert.equal(h.local.get('theme'),'imported');assert.equal(h.notes.at(-1)[1],'success');
});
test('replace clears main, legacy and full-origin localStorage',async()=>{
 const h=setup();h.load(backup({characters:[]},{newKey:'new'}));await h.apply('replace');assert.deepEqual([...h.main.data.keys()],['rp_hub_characters']);assert.equal(h.legacy.data.size,0);assert.deepEqual([...h.local],[['newKey','new']]);
});
for(const mode of ['merge','replace'])test(mode+' localStorage failure restores all original stores',async()=>{
 const h=setup({failSet:2}),before=snapshot(h);h.load(backup({characters:[]},{theme:'changed',second:'fail'}));await h.apply(mode);assert.equal(snapshot(h),before);assert.match(h.notes.at(-1)[0],/已回滚/);assert.equal(h.api.storageStats.importing,false);
});
test('DB batch failure is atomic and original snapshot is restored',async()=>{
 const h=setup({failDb:[1]}),before=snapshot(h);h.load(backup({characters:[]}));await h.apply('replace');assert.equal(snapshot(h),before);assert.equal(h.notes.at(-1)[1],'error');
});
test('legacy clear failure restores already-committed main batch',async()=>{
 const h=setup({failLegacy:[1]}),before=snapshot(h);h.load(backup({characters:[]}));await h.apply('replace');assert.equal(snapshot(h),before);
});
test('rollback failure is surfaced and never reported as success',async()=>{
 const h=setup({failDb:[2],failSet:1});h.load(backup({characters:[]},{theme:'changed'}));await h.apply('replace');assert.match(h.notes.at(-1)[0],/回滚不完整/);assert.equal(h.notes.at(-1)[1],'error');assert.equal(h.api.storageStats.importing,false);
});
test('localStorage snapshot read failure stops before any mutations',async()=>{
 const h=setup({failRead:true}),before=snapshot(h);h.load(backup({characters:[]}));await h.apply('replace');assert.equal(snapshot(h),before);assert.equal(h.main.writes+h.legacy.writes+h.writes,0);assert.match(h.notes.at(-1)[0],/localStorage/);
});
test('export includes legacy-only data and main wins logical duplicate',async()=>{
 const h=setup();h.legacy.data.set('silly_tavern_characters',[{name:'legacy duplicate'}]);await h.api.exportBackup();const p=JSON.parse(await h.downloads[0].text());assert.equal(p.entries.characters[0].name,'original');assert.equal(p.entries.chat_old[0].content,'old');assert.equal(p.localStorage.unrelated,'keep');
});
test('export localStorage failures abort download with explicit error',async()=>{
 const h=setup({failRead:true});await h.api.exportBackup();assert.equal(h.downloads.length,0);assert.match(h.notes.at(-1)[0],/localStorage/);assert.equal(h.notes.at(-1)[1],'error');
});
test('beforeImport rejects busy app before initialization or mutation',async()=>{
 let h;h=setup({beforeImport:async()=>{assert.equal(h.api.storageStats.importing,true);throw Error('busy generation')}});const before=snapshot(h);h.load(backup({characters:[]}));await h.apply('merge');assert.equal(snapshot(h),before);assert.equal(h.inits,0);assert.equal(h.main.writes+h.legacy.writes+h.writes,0);assert.match(h.notes.at(-1)[0],/busy generation/);assert.equal(h.api.storageStats.importing,false);
});
test('beforeImport is awaited before snapshots and successful restore',async()=>{
 let h;h=setup({beforeImport:async()=>{assert.equal(h.api.storageStats.importing,true);assert.equal(h.inits,0);await new Promise(r=>setImmediate(r));h.main.data.set('rp_hub_drained_queue','saved')}});h.load(backup({characters:[]}));await h.apply('merge');assert.equal(h.main.data.get('rp_hub_drained_queue'),'saved');assert.equal(h.notes.at(-1)[1],'success');
});

