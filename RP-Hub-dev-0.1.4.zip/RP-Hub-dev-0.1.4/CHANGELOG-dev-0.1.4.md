# Dev 0.1.4

基于 Dev 0.1.3，本次为用户定制改动，未触碰生图服务逻辑：

## API 供应商精简
- `assets/js/core-utils.js` 的 `apiProviderOptions` 仅保留 **SiliconFlow（硅基流动）**，移除 **DeepSeek**、**OpenRouter**、**STA1N** 聊天供应商。
- 默认值同步切换：`defaultApiProviderId` → `siliconflow`，`defaultApiConfig.apiUrl` → `https://api.siliconflow.cn/v1`。
- 设置页「获取API」链接从 `cdn.sta1n.cn/keys` 改为硅基流动密钥页 `https://cloud.siliconflow.cn/account/ak`。
- 老用户若此前选择了已移除的供应商，打开设置会自动回退到硅基流动（原密钥保留在本地存储，可重新填入）。
- 生图服务 API（`imageGenBaseUrl`、生图密钥、额度查询、生图设置）**保持不动**。

## 设置项折叠
- 「API 连接与服务」与「高级设置」两张卡片改为可折叠（仿「记忆系统设置」）：
  - 卡片头部变为可点击按钮，右侧带箭头；默认收起，点击展开后再填写与修改。
  - 在 `index.html` 用 `.settings-collapse` / `.is-open` 包裹卡片主体；`assets/js/app.js` 新增 `showApiConnectionSettings`、`showAdvancedSettings` 两个状态变量（默认 `false`）并暴露给模板。

## 版本
- VERSION / 入口 meta（`rphub-dev-version`）/ 标题 已更新为 0.1.4。
- 这是源码包，不是已构建 APK。

## 兼容性提示
- 三个改动文件需一起生效（`index.html`、`assets/js/core-utils.js`、`assets/js/app.js`）；若与旧版文件混用可能出现页面空白，请确保整包替换。
