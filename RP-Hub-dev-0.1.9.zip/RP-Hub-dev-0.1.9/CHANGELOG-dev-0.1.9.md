# RP-Hub Dev 0.1.9

基于 Dev 0.1.8 的修复版本，继续处理上一版遗留的三类问题：出图 token 泄漏、预览沙箱、外部 CDN 依赖。

## 1. 出图地址不再暴露 token

- 生图任务接口只接受 `?token=` 查询参数，之前图片地址直接写进 `<img src>`，token 会留在页面 URL、截图、开发者工具与 `reload` 的历史记录里。
- 现在 `renderGeneratedImageJob` 仍先赋原地址（保证首帧可用），随后用 `fetch(url, { credentials: 'omit', referrerPolicy: 'no-referrer' })` 取回图片，成功后替换为 `blob:` 地址；相同地址只取一次。
- 新增 `imageBlobUrls` / `imageBlobLoads` 缓存、`releaseImageBlobUrl` / `loadImageBlobUrl`；任务刷新时回收过期 blob，`onBeforeUnmount` 统一回收，避免内存堆积。
- 注意：请求本身仍带 token 查询参数（这是服务端接口约定），本次消除的是 token 长时间停留在 DOM/历史记录中的问题。

## 2. 角色卡工坊预览沙箱收紧

- `character/index.html` 三处 `<iframe ... sandbox="allow-scripts allow-same-origin">` 同时开启 `allow-scripts` 与 `allow-same-origin`，等于没有沙箱。现在改为
  `allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals`。
- 沙箱变为不透明源后，预览页不能再直接调用父页面的 `triggerSlash`。预览脚本改为向父页面 `postMessage({ type: 'RPHUB_PREVIEW_SLASH', command })`，目标源从 `data-rphub-origin` 读取。
- 主页面 `character/index.html` 的消息监听先做 `isAppOrigin(origin)` 校验，再处理 `RPHUB_PREVIEW_SLASH`（预览页源为 `null`，只能靠来源上下文 + 类型校验），其余消息仍要求 `event.source === window.parent`。
- 预览模板默认文档里的 Tailwind 也改为本地 `../assets/vendor/tailwind.js`。

## 3. 去掉全部外部 CDN 依赖

原来的页面在启动阶段要从 `unpkg`、`cdn.jsdelivr.net`、`cdn.tailwindcss.com`、`fonts.googleapis.com` 取 Vue、Tailwind、marked、daisyUI、localforage 与字体，断网、内网或被墙时页面直接起不来。现在全部改为随包资源：

- `index.html`：字体改用 `assets/vendor/fonts/local-fonts.css`。
- `novel/index.html`：Vue / Tailwind / marked 改用 `../assets/vendor/*`，字体同上。
- `character/index.html`：Vue、Tailwind、localforage 改用本地文件；daisyUI 改为本地 `assets/vendor/daisyui.css`（组件样式 + 主题变量）+ `assets/vendor/daisyui-theme.js`（占位脚本，保持原有引用顺序）。
- 新增 `assets/vendor/localforage.min.js`：与 localforage 1.10.0 接口兼容的离线实现（优先 IndexedDB，回落 localStorage），角色卡工坊的角色库读写不受影响。
- 新增 `assets/vendor/fonts/local-fonts.css`：把 Inter / JetBrains Mono / Lora / Noto Serif SC / Ma Shan Zheng 映射到本机同类字体，全部 `local()` 未命中时回落到系统字体。
- `assets/js/tailwind-theme.js` 增加 daisyUI 语义色（`base-100`、`base-content`、`primary`、`warning` 等）到 Tailwind 配置，`bg-base-100`、`text-base-content` 这类工具类在本地也能生成。
- `assets/css/theme.css` 的 daisyUI 令牌改为合法的 `hsl()` 分量格式（原先写的是 `oklch` 分量却当 hsl 用，颜色实际是无效值）；浅色配色表与组件规则集中到 `assets/vendor/daisyui.css`，深色配色仍在 `theme.css` 覆盖。

## 4. 版本

- `VERSION`、`index.html` 版本注释与标题、`assets/js/update-check.js` 注释统一为 0.1.9。

## 未随包改动

- 上游 2.0.3 的界面改版与标签体系仍未回移（与 0.1.x 的 `<prohibited_content>` 结构绑定）。
- 卡片的 `unsafe-inline` 级 HTML 清洗策略保持原状：卡片仍会在独立 iframe 中以不透明源渲染。
