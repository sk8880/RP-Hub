// Shared Tailwind theme for RP Hub, the character workshop and the novel editor.
// Palette steps read CSS variables from theme.css, so dark mode only swaps variables
// instead of overriding individual utility classes.
(function () {
    const steps = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900];
    const rgb = name => `rgb(var(--${name}) / <alpha-value>)`;
    // Optional role variables (e.g. --primary-text-600) fall back to the base step.
    const scale = (name, role) => Object.fromEntries(steps.map(step => [step, role
        ? `rgb(var(--${name}-${role}-${step}, var(--${name}-${step})) / <alpha-value>)`
        : rgb(`${name}-${step}`)]));

    // secondary/accent/neutral/info/success/warning/error 只在 daisyUI 语义色里用到，
    // 色阶变量（--secondary-500 等）theme.css 没有定义，所以这里给空对象，避免生成空色阶。
    const colors = {
        gray: scale('gray'),
        stone: scale('stone'),
        primary: scale('primary'),
        blue: scale('primary'),
        red: scale('red'),
        green: scale('green'),
        emerald: scale('green'),
        yellow: scale('amber'),
        amber: scale('amber'),
        orange: scale('amber'),
        secondary: {},
        accent: {},
        neutral: {},
        info: {},
        success: {},
        warning: {},
        error: {}
    };
    // Text and dark fills need their own steps in dark mode: light text on dark surfaces,
    // and 700-900 fills that stay dark behind white text.
    const textColor = {
        gray: scale('gray'),
        primary: scale('primary', 'text'),
        blue: scale('primary', 'text'),
        red: scale('red', 'text'),
        green: scale('green', 'text'),
        emerald: scale('green', 'text'),
        yellow: scale('amber', 'text'),
        amber: scale('amber', 'text'),
        orange: scale('amber', 'text')
    };

    // daisyUI 语义色（bg-base-100 / text-base-content / btn-primary ...）走 theme.css 的
    // HSL 令牌（--p/--b1/--bc ...），由 assets/vendor/daisyui.css 提供同族规则。
    const hslToken = name => `hsl(var(--${name}) / <alpha-value>)`;
    const daisyColors = {
        'base-100': hslToken('b1'),
        'base-200': hslToken('b2'),
        'base-300': hslToken('b3'),
        'base-content': hslToken('bc'),
        // primary/secondary/accent/neutral 在 colors 里是色阶，这里用对象合并补上 DEFAULT，
        // 同时保留 --primary-500 之类的色阶变量。
        primary: { ...colors.primary, DEFAULT: hslToken('p'), content: hslToken('pc') },
        secondary: { ...colors.secondary, DEFAULT: hslToken('s'), content: hslToken('sc') },
        accent: { ...colors.accent, DEFAULT: hslToken('a'), content: hslToken('ac') },
        neutral: { ...colors.neutral, DEFAULT: hslToken('n'), content: hslToken('nc') },
        info: { ...colors.info, DEFAULT: hslToken('in'), content: hslToken('inc') },
        success: { ...colors.success, DEFAULT: hslToken('su'), content: hslToken('suc') },
        warning: { ...colors.warning, DEFAULT: hslToken('wa'), content: hslToken('wac') },
        error: { ...colors.error, DEFAULT: hslToken('er'), content: hslToken('erc') }
    };

    tailwind.config = {
        theme: {
            extend: {
                // Stacks live in theme.css so CSS and utilities share one definition.
                fontFamily: { sans: 'var(--font-sans)', serif: 'var(--font-serif)', mono: 'var(--font-mono)' },
                colors: { ...colors, ...daisyColors },
                textColor,
                backgroundColor: { white: rgb('surface'), gray: scale('gray', 'fill'), stone: scale('stone', 'fill') },
                gradientColorStops: { white: rgb('surface'), gray: scale('gray', 'fill'), stone: scale('stone', 'fill') },
                borderColor: { white: rgb('surface-edge') },
                ringColor: { white: rgb('surface-edge') },
                ringOffsetColor: { DEFAULT: 'rgb(var(--gray-50))' },
                animation: {
                    'fade-in': 'fade-in var(--dur-2) var(--ease-out) both',
                    'slide-up': 'rise-in var(--dur-3) var(--ease-out) both'
                },
                transitionTimingFunction: {
                    'modal-fade': 'var(--ease-out)',
                    spring: 'var(--ease-spring)'
                },
                boxShadow: {
                    card: 'var(--shadow-1)',
                    soft: 'var(--shadow-1)'
                }
            }
        }
    };
})();
