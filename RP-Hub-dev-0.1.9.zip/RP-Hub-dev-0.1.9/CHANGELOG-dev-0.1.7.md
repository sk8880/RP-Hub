# RP-Hub Dev 0.1.7

本版只做安全加固，不改动生成流程、提示词和预设文本。所有改动按「单机个人使用」的场景取舍：不必防御恶意访客，但要堵住「页面自己把密钥和权限交出去」的路径。

## 内嵌页面通信（app.js / character / novel / theme.js）

- `syncSettingsToGenerator` 不再把整个 `settings` 发给角色工坊，只发它真正用到的字段（供应商列表、自定义供应商地址、生图 Key / 模型 / 风格 / 数量、三个模型槽位、UI 模板模型）。**主 API Key 不再跨窗口传递**。
- 发送目标从 `'*'` 改为 `location.origin`。
- 主页面的 `WORKSHOP_READY`、`WORKSHOP_IMPORT_AND_PLAY`、`REQUEST_RPHUB_API_SETTINGS` 三个分支统一加了 `isSameAppOrigin(event.origin)` 校验；回包（`WORKSHOP_IMPORT_RESULT`、`RPHUB_API_SETTINGS`）改用 `event.origin`。
- `character/index.html` 与 `novel/index.html` 的 message 监听加了同源校验（额外放行 `'null'`，兼容 APK 里以透明源加载的情况），发送目标改为 `location.origin`。
- `theme.js` 的主题请求只有在自身 origin 为空或为 `null` 时才退回 `'*'`。

## HTML 卡片沙箱（data-services.js）

- `htmlIframeSandbox` 去掉 `allow-same-origin` 和 `allow-top-navigation-by-user-activation`。卡片脚本从此跑在不透明源里，摸不到主页面的 DOM、localStorage 和 Cookie。
- 为了在沙箱里仍然能正常使用，卡片脚本改成纯 postMessage 通信：
  - 高度：`RPHUB_FRAME_HEIGHT`（不再读 `window.frameElement`）；
  - 斜杠命令：`RPHUB_FRAME_SLASH`；
  - 记忆引用角标：`RPHUB_CITE_OPEN`，角标由卡片自己生成并自带上样式，不再依赖父页面的对象。
- 主页面新增对应的监听，严格按 `contentWindow === event.source` 找到发送方 iframe，只处理上述三种消息。

## 内容清洗（runtime-services.js）

- `cleanConfig` 不再放行 `script` 标签和 `srcdoc` / `sandbox` / `onclick` 属性，并把它们列入 `FORBID_TAGS` / `FORBID_ATTR`。需要执行脚本的 HTML 卡片仍然走沙箱 iframe，普通正文里不再执行任何脚本。

## 备份导出（runtime-services.js）

- `exportBackup` 会递归脱敏名称匹配 `apikey|api_key|key|token|secret|password` 的字段（深度上限 12，字符串置空、数字归零），导出的 JSON 里不再有明文密钥。
- 导入时若检测到脱敏痕迹，导出成功后额外提示「API Key 已脱敏，导入后请重新填写」。
- 导入逻辑不变：只覆盖备份里出现的键，其余保留。

## 在线状态服务（presence-server）

- `ALLOWED_ORIGINS` 默认值由 `*` 改为空字符串，即默认拒绝所有跨域来源。
- 403 判断提前到 OPTIONS 分支之前，预检请求同样受白名单约束；只有命中白名单时才回 `Access-Control-Allow-Origin`，不再回落到 `*`。
- `file://` 页面（Origin 为 `null` 或空）照常可用，无需任何配置。

## 版本

- `VERSION`、`index.html` 版本注释与标题、`assets/js/update-check.js` 注释统一为 0.1.7。

## 仍未改动

- `tests/provider-routing.test.cjs` 仍然失败（`fetchModels` 带 context 不返回模型），与 0.1.5 的失败点完全一致，属原有问题，本版未涉及。
