# RP-Hub Dev 0.1.8

基于 Dev 0.1.7。本版处理审核清单里剩下的三项：备份导入的密钥覆盖、模型列表取不到、卡片依赖外部 CDN；不改动提示词与预设文本。

## 备份导入不再用空值覆盖密钥（runtime-services.js）

- 0.1.7 只做了「导出时脱敏」。导入端把空字符串照原样写回 localStorage，结果是把本机还能用的 API Key 冲掉了。
- 新增导入侧过滤 `prepareLocalImport`：写回前逐个解析 localStorage 的 JSON 值，名称匹配 `apikey|api_key|key|token|secret|password` 且值为空白字符串 / 0 / 空数组 / 空对象的字段**整键跳过**。
- 「密钥容器且里面全是空值」的整层也会被丢掉（例如 `apiProviderKeys:{"p1":""}`），不会留下半残结构。
- 没有密钥字段的 localStorage 键按原始字符串原样写回，不重新序列化；非空白、正常填写的密钥照常导入。
- 合并模式的回滚改为按备份原始键集处理，跳过过的键也会恢复成导入前的值。
- 导入完成后的提示改为「备份中的密钥已脱敏，请在设置里重新填写各接口 Key」。

## 模型列表按供应商 + 接口地址缓存（app.js）

- `fetchModels` 之前直接写 `providerModels[providerId]`，供应商改了 API 地址后仍会拿到旧地址的模型列表。
- 新增 `providerModelsApiUrl` 记录每份缓存对应的 `apiUrl`，新增 `getProviderApiUrl` / `readProviderModels` / `writeProviderModels`。
- 地址变了旧缓存自动失效，模型选择器回落到当前供应商的 `availableModels`。
- 顺带修掉审核里「带 context 调 `fetchModels` 返回 null」的问题：真正的成因是测试夹具里没有 `providerModels`，抛 ReferenceError 被 catch 吞掉。测试夹具补上 `providerModels:{}` 后，`tests/provider-routing.test.cjs` 由 9/10 变为 10/10。

## 卡片不再依赖外部 CDN（data-services.js / assets/vendor）

- 新增本地副本 `assets/vendor/jquery.min.js`（jQuery v3.7.1，87 KB），卡片的 `<script src>` 改为指向它，断网或用不了 jsdelivr 时卡片照常工作。
- 地址用 `new URL(path, window.location.href)` 现算：srcdoc 卡片里的相对路径会解析到页面根目录下多一层的 `assets`，直接写相对路径会 404；本地文件打开（`file://`）也能正确命中。
- 卡片 `<head>` 里预先写入主页面 origin（`<meta name="rphub-origin">` + 一行设置 `data-rphub-origin` 的脚本），卡片脚本的 `cardParentOrigin` 优先读它。srcdoc 文档是透明源，之前按祖先 origin 推断，在子路径部署时可能推错，导致 postMessage 被主页面丢弃。
- 卡片脚本外部依赖只剩这一个本地文件；`$` 由它提供，不再有任何第三方 CDN 请求。

## 测试

- `tests/provider-routing.test.cjs`：10/10（原 9/10）。
- `tests/backup-runtime.test.cjs`：13/13。
- `tests/model-selector.cjs`、`tests/st-presets.cjs`、`tests/update-disabled.cjs`：PASS。

## 版本

- `VERSION`、`index.html` 版本注释与标题、`assets/js/update-check.js` 注释统一为 0.1.8。

## 仍未处理（按个人单机使用暂不改）

- 主线 2.0.3 的界面改版与「最终分析」提示词没有回移。
- 生图接口返回给前端的 `/api/jobs/<id>/content?token=` 仍然把 token 放在 URL 里。
- `character/index.html` 里三处 `sandbox="allow-scripts allow-same-origin"` 的 iframe 没有改动（角色工坊内嵌预览需要同源）。
